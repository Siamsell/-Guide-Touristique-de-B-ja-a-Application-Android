# Guide Touristique — Béjaïa

Application Android (Java) de guide touristique de la ville de Béjaïa : catégories de lieux
(plages, montagnes, sites historiques, musées, restaurants, parcs…), fiches détaillées avec
galerie d'images, appel téléphonique direct et choix de la langue (anglais / arabe).

## Équipe
Sellami Siham · Bedjbedj Fatma Zouhra · Ikram Saidani · Rania Gariti

## Technologies
- Java, Android SDK (minSdk 24, targetSdk 35)
- Gradle (Kotlin DSL), Material Components, ConstraintLayout, GridLayout

## Lancer le projet
1. Ouvrir le dossier dans **Android Studio**.
2. Laisser Gradle synchroniser (Android Studio crée `local.properties` automatiquement).
3. Lancer sur un émulateur ou un téléphone (▶ Run).

## Structure
```
app/src/main/java/com/siham/guidetoristique/   # Activities, adapters, models
app/src/main/res/                              # layouts, images, chaînes (EN / AR)
```
