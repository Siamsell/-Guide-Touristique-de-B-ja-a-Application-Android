// Toimplementation 'com.yarolegovich:discrete-scrollview:1.5.1'p-level build file where you can add configuration options common to all sub-projects/modules.
plugins {

    alias(libs.plugins.android.application) apply false
}